# Galaxies

A Pen created on CodePen.io. Original URL: [https://codepen.io/actarian/pen/GWmqNY](https://codepen.io/actarian/pen/GWmqNY).

This code renders a spiral galaxy using threejs